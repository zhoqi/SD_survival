# Qing Zhong, USZ/UZH, 2016.07.01
# This scripts plots Kaplan-Meier curves and calculate univariate and multivariate Cox regression

rm(list=ls())
library(survival)
library(OIsurv)
library(foreign)

source('plotsurv.R')
tmp <- read.spss('data.sav',to.data.frame=TRUE,use.value.labels=FALSE)
pten <- tmp[tmp$tiss==1,] # only RPE cases

name <- "PTEN_FISH_percent_d60"
title <- "PTEN % Abberant nuclei"
name2 <- "PTEN_FISH_ratio_d60"
title2 <- "PTEN Ratio"

par(mfrow = c(1, 2))
plotsurv(pten, name, title, "os", "st_os_gen", "Overall survival")
plotsurv(pten, name2, title2, "os", "st_os_gen", "Overall survival")

par(mfrow = c(1, 2))
plotsurv(pten, name, title, "os", "st_os_spec", "Disease-specific survival")
plotsurv(pten, name2, title2, "os", "st_os_spec", "Disease-specific survival")

par(mfrow = c(1, 2))
plotsurv(pten, name, title, "rfs", "st_rfs", "Recurrence-free survival")
plotsurv(pten, name2, title2, "rfs", "st_rfs", "Recurrence-free survival")

##########################################################
# An example: anivariate cox regression for PTEN_FISH_ratio_d60
mod <- coxph(Surv(pten$os, pten$st_os_gen) ~ pten$PTEN_FISH_ratio_d60, method ="breslow")
summary(mod)

##########################################################
# Multivariate Cox regression
data <- pten[c("os", "st_os_gen", "GLE_t", "pT_t", "R1","PTEN_FISH_ratio_d60")] 
data <- na.omit(data)
attach(data)
mod <- coxph(Surv(os, st_os_gen) ~ GLE_t+pT_t+R1+PTEN_FISH_ratio_d60, method ="breslow")
summary(mod)

# Multivariate Cox regression with stepwise reverse selection
summary(step(mod))
detach(data)