# Qing Zhong, USZ/UZH, 2016.07.01

plotsurv <- function (dat, name, title, time, status, yl)

{
  data <- dat[c(time, status, name)]
  nr <- nrow(data)
  data <- na.omit(data)
  attach(data)
  var <- eval(parse(text=name))
  os <- eval(parse(text=time))
  st <- eval(parse(text=status))
  colo <- c(rgb(0,0.75,1), rgb(1,0.3,0))
          
  plot.new()
  for(i in 0:1){
    my.surv <- Surv(os[var==i], st[var==i])
    my.cb <- confBands(my.surv, confLevel=0.95, type="hall")
    fit <- survfit(my.surv ~ 1)
    s <- summary(fit, censored=TRUE)
    par(new=TRUE)
    plot(fit, col = colo[1+i], xlab="months", ylab=yl, main = title, xlim=c(-7,200))
    legend(160, min(fit$surv)-i*0.1, paste("N=",length(os[var==i])), box.col=NA)
    lines(my.cb, col = colo[1+i], lty=3)
  }
  
  logrank <- survdiff(Surv(os, st) ~ var)
  pval <- 1 - pchisq(logrank$chisq, length(logrank$n) - 1)
  num <-  nr -  nrow(data)
  
  if (pval < 0.001) {
    legend(-8,0.05, "p<0.001", box.col=NA)
  } else {
    legend(-8,0.05, paste(sep = "", "p=", toString(round(pval,digits = 3))), box.col=NA)
  }
  legend(-8,0.15, paste(sep = "", "(", toString(num), " missing observations)"), box.col=NA)
  legend(-8,0.3, col = colo, lty= 1, c(paste(title, "< 60%"), paste(title, ">= 60%")), box.col=NA)
  detach(data)
}